const display = document.getElementById('display');
const clearBtn = document.getElementById('clear');
const backspaceBtn = document.getElementById('backspace');
const sqrtBtn = document.getElementById('sqrt');
const divideBtn = document.getElementById('divide');
const multiplyBtn = document.getElementById('multiply');
const subtractBtn = document.getElementById('subtract');
const addBtn = document.getElementById('add');
const equalsBtn = document.getElementById('equals');
const numberBtns = document.querySelectorAll('#zero, #one, #two, #three, #four, #five, #six, #seven, #eight, #nine');
const decimalBtn = document.getElementById('decimal');

let currentNumber = '';
let previousNumber = '';
let operator = '';

numberBtns.forEach(button => {
    button.addEventListener('click', () => {
        currentNumber += button.textContent;
        display.value = currentNumber;
    });
});

decimalBtn.addEventListener('click', () => {
    if (!currentNumber.includes('.')) {
        currentNumber += '.';
        display.value = currentNumber;
    }
});

clearBtn.addEventListener('click', () => {
    currentNumber = '';
    previousNumber = '';
    operator = '';
    display.value = '';
});

backspaceBtn.addEventListener('click', () => {
    currentNumber = currentNumber.slice(0, -1);
    display.value = currentNumber;
});

sqrtBtn.addEventListener('click', () => {
    currentNumber = Math.sqrt(parseFloat(currentNumber)).toString();
    display.value = currentNumber;
});

divideBtn.addEventListener('click', () => {
    previousNumber = currentNumber;
    operator = '/';
    currentNumber = '';
    display.value = '';
});

multiplyBtn.addEventListener('click', () => {
    previousNumber = currentNumber;
    operator = '*';
    currentNumber = '';
    display.value = '';
});

subtractBtn.addEventListener('click', () => {
    previousNumber = currentNumber;
    operator = '-';
    currentNumber = '';
    display.value = '';
});

addBtn.addEventListener('click', () => {
    previousNumber = currentNumber;
    operator = '+';
    currentNumber = '';
    display.value = '';
});

equalsBtn.addEventListener('click', () => {
    let result;
    switch (operator) {
        case '+':
            result = parseFloat(previousNumber) + parseFloat(currentNumber);
            break;
        case '-':
            result = parseFloat(previousNumber) - parseFloat(currentNumber);
            break;
        case '*':
            result = parseFloat(previousNumber) * parseFloat(currentNumber);
            break;
        case '/':
            if (currentNumber === '0') {
                display.value = 'Error: Division by zero';
                return;
            }
            result = parseFloat(previousNumber) / parseFloat(currentNumber);
            break;
        default:
            result = 0;
    }
    display.value = result;
    currentNumber = result.toString();
    previousNumber = '';
    operator = '';
});