let tasks = [];

const taskInput = document.getElementById('task-input');
const taskDescription = document.getElementById('task-description');
const addTaskBtn = document.getElementById('add-task-btn');
const tasksTbody = document.getElementById('tasks-tbody');

addTaskBtn.addEventListener('click', addTask);

function addTask() {
    const taskTitle = taskInput.value.trim();
    const taskDesc = taskDescription.value.trim();
    if (taskTitle && taskDesc) {
        const newTask = {
            id: Date.now(),
            title: taskTitle,
            description: taskDesc
        };
        tasks.push(newTask);
        renderTasks();
        taskInput.value = '';
        taskDescription.value = '';
    }
}

function renderTasks() {
    tasksTbody.innerHTML = '';
    tasks.forEach(task => {
        const taskHTML = `
            <tr>
                <td>${task.title}</td>
                <td>${task.description}</td>
                <td><button class="delete-btn" data-id="${task.id}"><i class="fas fa-trash"></i> Delete</button></td>
            </tr>
        `;
        tasksTbody.insertAdjacentHTML('beforeend', taskHTML);
    });
    const deleteBtns = document.querySelectorAll('.delete-btn');
    deleteBtns.forEach(btn => {
        btn.addEventListener('click', deleteTask);
    });
}

function deleteTask(e) {
    const taskId = parseInt(e.target.dataset.id);
    tasks = tasks.filter(task => task.id!== taskId);
    renderTasks();
}