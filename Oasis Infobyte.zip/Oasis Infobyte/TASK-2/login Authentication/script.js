// Get the flip card and button elements
const flipCard = document.querySelector('.flip-card-inner');
const newButton = document.getElementById('new-user-button');
const loginButton = document.getElementById('login-button');

// Get the forms and secured page elements
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const securedPage = document.getElementById('secured-page');

// Function to flip the card
function flipCardFunction() {
    flipCard.classList.toggle('flipped');
}

// Function to register a new user
function registerUser(username, password) {
    // Check if the username already exists
    if (localStorage.getItem(username)) {
        alert('Username already exists');
        return;
    }

    // Hash the password
    const hashedPassword = hashPassword(password);

    // Store the user credentials in local storage
    localStorage.setItem(username, hashedPassword);
    alert('User registered successfully');
}

// Function to login a user
function loginUser(username, password) {
    // Get the stored user credentials
    const storedPassword = localStorage.getItem(username);

    // Check if the username exists
    if (!storedPassword) {
        alert('Username does not exist');
        return;
    }

    // Hash the input password
    const hashedPassword = hashPassword(password);

    // Check if the passwords match
    if (hashedPassword!== storedPassword) {
        alert('Invalid password');
        return;
    }

    // Show the secured page
    securedPage.style.display = 'block';
}

// Function to hash a password
function hashPassword(password) {
    // Use a simple hash function for demonstration purposes
    return password.split('').map(char => char.charCodeAt(0)).join('');
}

// Add event listeners to the buttons and forms
newButton.addEventListener('click', flipCardFunction);
loginButton.addEventListener('click', flipCardFunction);

loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    loginUser(username, password);
});

registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    registerUser(username, password);
});