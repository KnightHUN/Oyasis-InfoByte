const rooms = [
    {
        id: 1,
        name: 'Single Room',
        description: 'This is a single room with a single bed.',
        price: '$100 per night'
    },
    { 
        id: 2,
        name: 'Double Room',
        description: 'This is a double room with two beds.',
        price: '$150 per night'
    },
    {
        id: 3,
        name: 'Suite Room',
        description: 'This is a suite room with a king-size bed and a living room.',
        price: '$250 per night'
    }
];

const roomGrid = document.querySelector('.room-grid');
const roomDetails = document.querySelector('#room-details');
const roomDetailsContent = document.querySelector('.room-details-content');
const roomName = document.querySelector('#room-name');
const roomDescription = document.querySelector('#room-description');
const roomPrice = document.querySelector('#room-price');
const bookNow = document.querySelector('#book-now');

roomGrid.addEventListener('click', (e) => {
    if (e.target.classList.contains('room')) {
        const roomId = e.target.dataset.id;
        const room = rooms.find((room) => room.id == roomId);
        roomName.textContent = room.name;
        roomDescription.textContent = room.description;
        roomPrice.textContent = room.price;
        roomDetails.style.display = 'block';
    }
});

roomDetails.addEventListener('click', (e) => {
    if (e.target == roomDetails) {
        roomDetails.style.display = 'none';
    }
});

bookNow.addEventListener('click', () => {
    alert('Room booked successfully!');
    roomDetails.style.display = 'none';
});