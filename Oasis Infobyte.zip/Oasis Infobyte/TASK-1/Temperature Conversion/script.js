const temperatureInput = document.getElementById('temperature');
const unitSelect = document.getElementById('unit');
const convertBtn = document.getElementById('convert-btn');
const resultPara = document.getElementById('result');

convertBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const temperature = parseFloat(temperatureInput.value);
    const unit = unitSelect.value;

    if (isNaN(temperature)) {
        resultPara.textContent = 'Please enter a valid temperature';
        return;
    }

    let convertedTemperature;
    let convertedUnit;

    switch (unit) {
        case 'celsius':
            convertedTemperature = temperature * 9 / 5 + 32;
            convertedUnit = 'Fahrenheit';
            break;
        case 'fahrenheit':
            convertedTemperature = (temperature - 32) * 5 / 9;
            convertedUnit = 'Celsius';
            break;
        case 'kelvin':
            convertedTemperature = temperature - 273.15;
            convertedUnit = 'Celsius';
            break;
        default:
            resultPara.textContent = 'Invalid unit';
            return;
    }

    // Additional conversion to Kelvin
    if (unit === 'celsius') {
        const kelvinTemperature = temperature + 273.15;
        resultPara.textContent = `${temperature} ${unit.charAt(0).toUpperCase() + unit.slice(1)} is equal to ${convertedTemperature.toFixed(2)} ${convertedUnit} and ${kelvinTemperature.toFixed(2)} Kelvin`;
    } else if (unit === 'fahrenheit') {
        const kelvinTemperature = (temperature - 32) * 5 / 9 + 273.15;
        resultPara.textContent = `${temperature} ${unit.charAt(0).toUpperCase() + unit.slice(1)} is equal to ${convertedTemperature.toFixed(2)} ${convertedUnit} and ${kelvinTemperature.toFixed(2)} Kelvin`;
    } else {
        resultPara.textContent = `${temperature} ${unit.charAt(0).toUpperCase() + unit.slice(1)} is equal to ${convertedTemperature.toFixed(2)} ${convertedUnit}`;
    }
});